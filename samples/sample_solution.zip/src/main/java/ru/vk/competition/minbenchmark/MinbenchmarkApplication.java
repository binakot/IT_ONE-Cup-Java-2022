package ru.vk.competition.minbenchmark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinbenchmarkApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinbenchmarkApplication.class, args);
    }

}
