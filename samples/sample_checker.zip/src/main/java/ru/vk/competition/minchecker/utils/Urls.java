package ru.vk.competition.minchecker.utils;

public interface Urls {

    String SINGLE_QUERY = "single-query/";
    String ADD_NEW_QUERY_RESULT = "add-new-query-result";
    String ADD_SINGLE_QUERY = "add-new-query";
}
