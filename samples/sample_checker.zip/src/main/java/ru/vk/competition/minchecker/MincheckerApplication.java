package ru.vk.competition.minchecker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MincheckerApplication {

    public static void main(String[] args) {
        SpringApplication.run(MincheckerApplication.class, args);


    }

}
